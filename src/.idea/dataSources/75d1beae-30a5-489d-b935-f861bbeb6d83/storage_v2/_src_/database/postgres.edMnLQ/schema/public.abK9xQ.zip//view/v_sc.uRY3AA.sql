create view v_sc(s_num, c_num, score, c_name, c_credit) as
SELECT sc.s_num,
       sc.c_num,
       sc.score,
       course.c_name,
       course.c_credit
FROM sc,
     course
WHERE ((sc.c_num)::text = (course.c_num)::text);

alter table v_sc
    owner to postgres;

